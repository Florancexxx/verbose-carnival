package org.wit.marathon.console.models

data class MarathonModel(var id: Long = 0,
                         var place: String = "",
                         var distance: String = "")