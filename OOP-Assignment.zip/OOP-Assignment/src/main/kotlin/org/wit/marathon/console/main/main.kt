package org.wit.marathon.console.main

import org.wit.marathon.console.controllers.MarathonController

fun main(args: Array<String>) {
    MarathonController().start()
}

